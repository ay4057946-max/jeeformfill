package com.jeeguide.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import android.content.Intent

@Composable
fun InfoScreen(st: AppState) {
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenHeader("Dates, fees and info", "From the JEE (Main) 2027 bulletin") }

        item {
            AppCard {
                Text("Session 1 · January 2027", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(6.dp))
                session1Dates.forEachIndexed { i, d -> TimelineRow(d, i == session1Dates.lastIndex) }
            }
        }
        item {
            AppCard {
                Text("Session 2 · April 2027", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(6.dp))
                session2Dates.forEachIndexed { i, d -> TimelineRow(d, i == session2Dates.lastIndex) }
            }
        }
        item {
            AppCard {
                Text("Fee: one paper (Paper 1 or 2A or 2B)", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(8.dp))
                FeeRow(listOf("Category", "Gender", "India", "Abroad"), header = true)
                feeSingle.forEach { FeeRow(it) }
                Spacer(Modifier.height(14.dp))
                Text("Fee: two papers", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(8.dp))
                FeeRow(listOf("Category", "Gender", "India", "Abroad"), header = true)
                feeDouble.forEach { FeeRow(it) }
                Spacer(Modifier.height(10.dp))
                Text(
                    "Fees are per session. Bank / gateway charges and GST are extra. Fee once paid is not refundable. Late fee: extra ₹500.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        item {
            AppCard {
                Text("Exam at a glance", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(6.dp))
                listOf(
                    "Paper 1 (B.E./B.Tech): computer-based test with Mathematics, Physics and Chemistry.",
                    "Paper 2A (B.Arch): Mathematics, Aptitude Test and Drawing Test.",
                    "Paper 2B (B.Planning): Mathematics, Aptitude Test and Planning-based questions.",
                    "Two sessions each year. Your best NTA score is used for the rank list.",
                    "Class 12 (or equivalent) passed in 2025 or 2026, or appearing in 2027, can apply."
                ).forEach { t ->
                    Row(Modifier.padding(vertical = 2.dp)) {
                        Text("•  ", color = MaterialTheme.colorScheme.primary)
                        Text(t, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            AppCard {
                Text("Help and official links", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { ctx.openUri(OFFICIAL_SITE) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Text("Open official JEE Main website")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { ctx.openUri("tel:01140759000", Intent.ACTION_DIAL) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Text("Call NTA: 011-40759000 / 69227700")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { ctx.openUri("mailto:jeemain@nta.ac.in") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Text("Email: jeemain@nta.ac.in")
                }
            }
        }
        item {
            AppCard {
                Text("Your data", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Everything is stored locally on this device. Delete it all once your form is submitted.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Text("Erase all saved details and ticks", color = MaterialTheme.colorScheme.error)
                }
            }
        }
        item {
            Text(
                "This is an unofficial guide made from the NTA Information Bulletin. If anything differs, the official website and bulletin are final.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 6.dp)
            )
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Erase everything?") },
            text = { Text("All saved details and checklist ticks will be deleted from this phone.") },
            confirmButton = { TextButton(onClick = { st.clearAll(); confirm = false }) { Text("Erase") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun FeeRow(cells: List<String>, header: Boolean = false) {
    val weights = listOf(2.2f, 1.1f, 1f, 1f)
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        cells.forEachIndexed { i, c ->
            Text(
                c,
                modifier = Modifier.weight(weights[i]),
                style = MaterialTheme.typography.bodySmall,
                fontWeight = if (header) FontWeight.Bold else FontWeight.Normal,
                color = if (header) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
