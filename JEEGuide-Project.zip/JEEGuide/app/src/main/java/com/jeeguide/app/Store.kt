package com.jeeguide.app

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf

/** Local-only storage (SharedPreferences). The app has no internet permission. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jee_guide_store", Context.MODE_PRIVATE)
    fun get(k: String): String = sp.getString(k, "") ?: ""
    fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }
    fun getBool(k: String): Boolean = sp.getBoolean(k, false)
    fun putBool(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    fun clear() { sp.edit().clear().apply() }
}

class AppState(private val store: Store) {
    val vault = mutableStateMapOf<String, String>()
    val checks = mutableStateMapOf<String, Boolean>()

    init {
        vaultGroups.forEach { g -> g.fields.forEach { f -> vault[f.key] = store.get("v_" + f.key) } }
        checklist.forEach { s -> s.items.forEach { i -> checks[i.id] = store.getBool("c_" + i.id) } }
    }

    fun setVault(key: String, value: String) {
        vault[key] = value
        store.put("v_$key", value)
    }

    fun toggle(id: String) {
        val now = !(checks[id] ?: false)
        checks[id] = now
        store.putBool("c_$id", now)
    }

    fun resetChecks() {
        checks.keys.toList().forEach { checks[it] = false; store.putBool("c_$it", false) }
    }

    fun clearAll() {
        store.clear()
        vault.keys.toList().forEach { vault[it] = "" }
        checks.keys.toList().forEach { checks[it] = false }
    }
}
