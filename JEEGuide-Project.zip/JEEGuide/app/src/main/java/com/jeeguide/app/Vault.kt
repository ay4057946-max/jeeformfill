package com.jeeguide.app

import android.widget.Toast
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun VaultScreen(st: AppState) {
    val total = vaultGroups.sumOf { it.fields.size }
    val filled = st.vault.count { it.value.isNotBlank() }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenHeader("My details", "Save once, then copy and paste into the form") }
        item {
            AppCard {
                Text("🔒 Stored only on this phone", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "This app has no internet permission, so nothing you type here is ever sent anywhere. Changes save automatically. Tap Copy next to a field, switch to the NTA portal and paste.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                Text("$filled of $total fields filled", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { if (total == 0) 0f else filled.toFloat() / total.toFloat() },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
                    color = MaterialTheme.colorScheme.tertiary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }
        }
        items(vaultGroups) { g -> GroupCard(g, st) }
    }
}

@Composable
private fun GroupCard(g: VaultGroup, st: AppState) {
    var open by rememberSaveable(g.title) { mutableStateOf(false) }
    val done = g.fields.count { !(st.vault[it.key] ?: "").isBlank() }
    AppCard(Modifier.animateContentSize(), onClick = { open = !open }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(g.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                if (g.note.isNotEmpty()) {
                    Text(g.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Pill(
                "$done/${g.fields.size}",
                if (done == g.fields.size) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                if (done == g.fields.size) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text("   " + (if (open) "▲" else "▼"), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (open) {
            Spacer(Modifier.height(12.dp))
            g.fields.forEach { f ->
                FieldRow(f, st)
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun FieldRow(f: VaultField, st: AppState) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var show by remember { mutableStateOf(false) }
    val value = st.vault[f.key] ?: ""
    val kb = when (f.kind) {
        1 -> KeyboardType.Number
        2 -> KeyboardType.Email
        3 -> KeyboardType.Phone
        else -> KeyboardType.Text
    }
    OutlinedTextField(
        value = value,
        onValueChange = { st.setVault(f.key, it) },
        label = { Text(f.label) },
        placeholder = { if (f.hint.isNotEmpty()) Text(f.hint) },
        singleLine = true,
        visualTransformation = if (f.secret && !show) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = kb),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
        trailingIcon = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (f.secret) {
                    TextButton(
                        onClick = { show = !show },
                        contentPadding = PaddingValues(horizontal = 6.dp)
                    ) { Text(if (show) "Hide" else "Show") }
                }
                TextButton(
                    onClick = {
                        clip.setText(AnnotatedString(value))
                        Toast.makeText(ctx, "Copied: " + f.label, Toast.LENGTH_SHORT).show()
                    },
                    enabled = value.isNotBlank(),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) { Text("Copy", fontWeight = FontWeight.Bold) }
            }
        }
    )
}
