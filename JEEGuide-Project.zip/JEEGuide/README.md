# JEE Main 2027 Guide (Android)
Kotlin + Jetpack Compose + Material 3. Offline, no internet permission.
Tabs: Home, Guide, Checklist, My Details (copy-paste vault), Info.
Build: `gradle assembleDebug` (Gradle 8.7, JDK 17). APK: app/build/outputs/apk/debug/
