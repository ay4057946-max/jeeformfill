package com.jeeguide.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            JeeTheme {
                val state = remember { AppState(Store(applicationContext)) }
                App(state)
            }
        }
    }
}

private data class Tab(val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("Home", Icons.Filled.Home),
    Tab("Guide", Icons.Filled.Menu),
    Tab("Fast Fill", Icons.Filled.Star),
    Tab("Docs", Icons.Filled.CheckCircle),
    Tab("Info", Icons.Filled.Info)
)

@Composable
fun App(st: AppState) {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var tutorial by rememberSaveable { mutableStateOf(false) }
    var fast by remember { mutableStateOf<List<Pair<String, VaultField>>?>(null) }

    fun startFast(list: List<Pair<String, VaultField>>) {
        if (list.isEmpty()) ctx.toast("Save some details first") else fast = list
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    tabs.forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(t.icon, contentDescription = t.label) },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).statusBarsPadding()) {
                when (tab) {
                    0 -> HomeScreen(
                        st,
                        go = { tab = it },
                        onTutorial = { tutorial = true },
                        onFastAll = { startFast(fastItems(st, vaultGroups)) }
                    )
                    1 -> GuideScreen(onTutorial = { tutorial = true })
                    2 -> VaultScreen(st) { startFast(it) }
                    3 -> DocsScreen(st)
                    else -> InfoScreen(st)
                }
            }
        }
        val f = fast
        if (f != null) FastFillScreen(f, st) { fast = null }
        if (tutorial) TutorialScreen { tutorial = false }
    }
}
