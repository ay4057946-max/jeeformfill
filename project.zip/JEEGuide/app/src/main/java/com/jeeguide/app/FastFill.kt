package com.jeeguide.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Every saved (non-empty) field of the given groups, in portal order. */
fun fastItems(st: AppState, groups: List<VaultGroup>): List<Pair<String, VaultField>> =
    groups.flatMap { g ->
        g.fields.filter { !(st.vault[it.key] ?: "").isBlank() }.map { Pair(g.title, it) }
    }

@Composable
fun FastFillScreen(items: List<Pair<String, VaultField>>, st: AppState, onClose: () -> Unit) {
    BackHandler { onClose() }
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var i by remember { mutableIntStateOf(0) }
    if (items.isEmpty()) { onClose(); return }
    val idx = i.coerceIn(0, items.size - 1)
    val group = items[idx].first
    val f = items[idx].second
    val v = st.vault[f.key] ?: ""
    var reveal by remember(idx) { mutableStateOf(false) }
    val shown = if (f.secret && !reveal) "••••••••" else v

    fun copy(): Unit {
        clip.setText(AnnotatedString(v))
        ctx.toast("Copied: " + f.label)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("⚡ Fast fill", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text(group, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = onClose) { Text("Done") }
        }
        Spacer(Modifier.height(8.dp))
        Text("Field ${idx + 1} of ${items.size}", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = { (idx + 1).toFloat() / items.size.toFloat() },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
        Spacer(Modifier.weight(1f))
        AppCard {
            Text(f.label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(10.dp))
            Column(Modifier.fillMaxWidth().height(110.dp).verticalScroll(rememberScrollState())) {
                Text(shown, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            }
            if (f.secret) {
                TextButton(onClick = { reveal = !reveal }) { Text(if (reveal) "Hide" else "Show") }
            }
        }
        Spacer(Modifier.weight(1f))
        Text(
            "Tap Copy, switch to the NTA portal, paste, then come back and tap Next.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { copy() },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Copy", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { if (idx > 0) i = idx - 1 },
                enabled = idx > 0,
                modifier = Modifier.weight(1f).height(48.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("◀ Prev") }
            OutlinedButton(
                onClick = { if (idx < items.size - 1) i = idx + 1 else onClose() },
                modifier = Modifier.weight(1f).height(48.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text(if (idx < items.size - 1) "Next ▶" else "Finish") }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                copy()
                if (idx < items.size - 1) i = idx + 1 else onClose()
            },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(14.dp),
            colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        ) { Text("Copy this & go next ▶", fontWeight = FontWeight.Bold) }
        TextButton(
            onClick = { ctx.openUri(OFFICIAL_SITE) },
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) { Text("Open NTA website") }
    }
}
