package com.jeeguide.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

object DocFiles {
    private fun dir(ctx: Context): File = File(ctx.filesDir, "docs").apply { mkdirs() }

    fun fileFor(ctx: Context, slot: DocSlot, meta: DocMeta): File =
        File(dir(ctx), slot.id + "." + meta.ext)

    fun deleteFor(ctx: Context, slot: DocSlot) {
        dir(ctx).listFiles()?.filter { it.name.startsWith(slot.id + ".") }?.forEach { it.delete() }
    }

    fun deleteAll(ctx: Context) {
        dir(ctx).listFiles()?.forEach { it.delete() }
    }

    fun fmtSize(bytes: Long): String =
        if (bytes < 1024L * 1024L) "${(bytes + 1023L) / 1024L} KB"
        else String.format("%.1f MB", bytes / 1048576.0)

    /** Returns (meetsLimits, label). */
    fun status(slot: DocSlot, meta: DocMeta): Pair<Boolean, String> {
        val size = fmtSize(meta.size)
        if (slot.maxKB == 0) return Pair(true, size)
        val min = slot.minKB * 1024L
        val max = slot.maxKB * 1024L
        return when {
            meta.size < min -> Pair(false, "$size · below ${slot.minKB} KB minimum")
            meta.size > max -> Pair(false, "$size · above ${slot.maxKB} KB limit")
            else -> Pair(true, "✓ $size · within NTA limit")
        }
    }

    /** Copies the picked file into app-private storage. Images are resized to fit the NTA limit. */
    fun import(ctx: Context, slot: DocSlot, uri: Uri): Pair<DocMeta?, String> {
        val cr = ctx.contentResolver
        var name = "document"
        try {
            cr.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
            }
        } catch (e: Exception) { }
        val mime = cr.getType(uri) ?: ""
        val bytes: ByteArray = try {
            cr.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Exception) {
            null
        } ?: return Pair(null, "Could not read that file")
        if (bytes.size > 40 * 1024 * 1024) return Pair(null, "File is too large (over 40 MB)")

        val lower = name.lowercase()
        val isImg = mime.startsWith("image/")
        val isPdf = mime == "application/pdf" || lower.endsWith(".pdf")
        val data: ByteArray
        val ext: String
        val outMime: String
        var note = ""

        if (slot.image) {
            if (!isImg) return Pair(null, "Please pick an image (JPG or PNG)")
            val max = slot.maxKB * 1024
            val min = slot.minKB * 1024
            if (mime == "image/jpeg" && bytes.size in min..max) {
                data = bytes
            } else {
                data = shrinkToJpeg(bytes, max) ?: return Pair(null, "Could not read that image")
                note = "Resized to fit the ${slot.maxKB} KB limit (was ${fmtSize(bytes.size.toLong())}). "
            }
            ext = "jpg"
            outMime = "image/jpeg"
        } else if (slot.maxKB > 0) {
            if (!isPdf) return Pair(null, "Please pick a PDF. Use a scanner app to turn photos into PDF.")
            data = bytes
            ext = "pdf"
            outMime = "application/pdf"
        } else {
            data = bytes
            ext = lower.substringAfterLast('.', "bin").filter { it.isLetterOrDigit() }.take(5).ifEmpty { "bin" }
            outMime = mime.ifEmpty { "application/octet-stream" }
        }

        deleteFor(ctx, slot)
        File(dir(ctx), slot.id + "." + ext).writeBytes(data)
        val shownName = if (slot.image) name.substringBeforeLast('.') + ".jpg" else name
        val meta = DocMeta(shownName, data.size.toLong(), outMime, ext)
        val st = status(slot, meta)
        val warn = if (st.first) "Saved. " else "Saved, but check size. "
        return Pair(meta, note + warn + fmtSize(data.size.toLong()))
    }

    private fun shrinkToJpeg(bytes: ByteArray, maxBytes: Int): ByteArray? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 3200 || bounds.outHeight / sample > 3200) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return null

        try {
            val exif = ExifInterface(ByteArrayInputStream(bytes))
            val deg = when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                6 -> 90f
                3 -> 180f
                8 -> 270f
                else -> 0f
            }
            if (deg != 0f) {
                val m = Matrix()
                m.postRotate(deg)
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
        } catch (e: Exception) { }

        // flatten transparency on white, cap size
        var cur = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        Canvas(cur).apply {
            drawColor(android.graphics.Color.WHITE)
            drawBitmap(bmp, 0f, 0f, null)
        }
        val big = maxOf(cur.width, cur.height)
        if (big > 1400) {
            val f = 1400f / big
            cur = Bitmap.createScaledBitmap(cur, (cur.width * f).toInt(), (cur.height * f).toInt(), true)
        }

        repeat(10) {
            var q = 90
            while (q >= 40) {
                val out = ByteArrayOutputStream()
                cur.compress(Bitmap.CompressFormat.JPEG, q, out)
                if (out.size() <= maxBytes) return out.toByteArray()
                q -= 10
            }
            cur = Bitmap.createScaledBitmap(
                cur,
                (cur.width * 0.85f).toInt().coerceAtLeast(60),
                (cur.height * 0.85f).toInt().coerceAtLeast(60),
                true
            )
        }
        val out = ByteArrayOutputStream()
        cur.compress(Bitmap.CompressFormat.JPEG, 30, out)
        return out.toByteArray()
    }

    fun thumb(ctx: Context, slot: DocSlot, meta: DocMeta): Bitmap? {
        if (!slot.image) return null
        val f = fileFor(ctx, slot, meta)
        if (!f.exists()) return null
        return try {
            BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = 4 })
        } catch (e: Exception) {
            null
        }
    }

    private fun uriFor(ctx: Context, f: File): Uri =
        FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)

    fun view(ctx: Context, slot: DocSlot, meta: DocMeta) {
        val f = fileFor(ctx, slot, meta)
        if (!f.exists()) { ctx.toast("File missing"); return }
        try {
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uriFor(ctx, f), meta.mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            ctx.toast("No app found to open this file")
        }
    }

    fun share(ctx: Context, slot: DocSlot, meta: DocMeta) {
        val f = fileFor(ctx, slot, meta)
        if (!f.exists()) { ctx.toast("File missing"); return }
        try {
            val i = Intent(Intent.ACTION_SEND)
                .setType(meta.mime)
                .putExtra(Intent.EXTRA_STREAM, uriFor(ctx, f))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(i, "Share " + slot.title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            ctx.toast("Could not share this file")
        }
    }

    /** Copies the file to Downloads/JEE Docs so the browser's file picker can find it. */
    fun saveToDownloads(ctx: Context, slot: DocSlot, meta: DocMeta) {
        val f = fileFor(ctx, slot, meta)
        if (!f.exists()) { ctx.toast("File missing"); return }
        if (Build.VERSION.SDK_INT < 29) {
            ctx.toast("On this Android version, use Share and save to Files")
            return
        }
        try {
            val clean = slot.title.filter { it.isLetterOrDigit() || it == ' ' }.trim().replace(' ', '_')
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "JEE2027_" + clean + "." + meta.ext)
                put(MediaStore.Downloads.MIME_TYPE, meta.mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/JEE Docs")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri == null) { ctx.toast("Could not save"); return }
            ctx.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            ctx.toast("Saved in Downloads/JEE Docs")
        } catch (e: Exception) {
            ctx.toast("Could not save to Downloads")
        }
    }
}
