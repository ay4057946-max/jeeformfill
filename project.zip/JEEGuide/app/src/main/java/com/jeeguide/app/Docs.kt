package com.jeeguide.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun DocsScreen(st: AppState) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var pending by remember { mutableStateOf<DocSlot?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val slot = pending
        if (uri != null && slot != null) {
            scope.launch {
                val res = withContext(Dispatchers.IO) { DocFiles.import(ctx, slot, uri) }
                val meta = res.first
                if (meta != null) st.setDoc(slot.id, meta)
                ctx.toast(res.second)
            }
        }
    }
    val reqDone = docSlots.count { it.required && st.docs.containsKey(it.id) }
    val reqTotal = docSlots.count { it.required }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenHeader("Documents", "Keep every upload ready in one place") }
        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(4.dp)
            ) {
                SegTab("Locker", tab == 0, Modifier.weight(1f)) { tab = 0 }
                SegTab("Checklist", tab == 1, Modifier.weight(1f)) { tab = 1 }
            }
        }
        if (tab == 0) {
            item {
                AppCard {
                    Text("🔒 Stored only on this phone", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Add your files once. Photos and signatures are resized automatically to meet the NTA limit. Use Save to Downloads, then pick the file from the portal's upload button.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("$reqDone of $reqTotal required uploads ready", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { if (reqTotal == 0) 0f else reqDone.toFloat() / reqTotal.toFloat() },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
                        color = MaterialTheme.colorScheme.secondary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
            items(docSlots) { slot ->
                SlotCard(slot, st) {
                    pending = it
                    picker.launch(if (it.image) "image/*" else if (it.maxKB > 0) "application/pdf" else "*/*")
                }
            }
        } else {
            checklistItems(st)
        }
    }
}

@Composable
private fun SegTab(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) cs.primary else cs.surfaceVariant)
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontWeight = FontWeight.SemiBold, color = if (selected) cs.onPrimary else cs.onSurfaceVariant)
    }
}

@Composable
private fun SlotCard(slot: DocSlot, st: AppState, onPick: (DocSlot) -> Unit) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val meta = st.docs[slot.id]
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(slot.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Text(slot.spec, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            if (slot.required) Pill("Required", cs.tertiaryContainer, cs.onTertiaryContainer)
        }
        Spacer(Modifier.height(10.dp))
        if (meta != null) {
            val s = DocFiles.status(slot, meta)
            val thumb = remember(meta) { DocFiles.thumb(ctx, slot, meta) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (thumb != null) {
                    Image(
                        bitmap = thumb.asImageBitmap(),
                        contentDescription = slot.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(64.dp).clip(RoundedCornerShape(12.dp))
                    )
                    Spacer(Modifier.width(12.dp))
                }
                Column(Modifier.weight(1f)) {
                    Pill(
                        s.second,
                        if (s.first) cs.secondaryContainer else cs.errorContainer,
                        if (s.first) cs.onSecondaryContainer else cs.onErrorContainer
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(meta.name, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1)
                }
            }
        } else {
            Text("Nothing added yet", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onPick(slot) }, shape = RoundedCornerShape(12.dp)) {
                Text(if (meta == null) "Add file" else "Replace")
            }
            if (meta != null) {
                OutlinedButton(onClick = { DocFiles.view(ctx, slot, meta) }, shape = RoundedCornerShape(12.dp)) { Text("View") }
                OutlinedButton(onClick = { DocFiles.share(ctx, slot, meta) }, shape = RoundedCornerShape(12.dp)) { Text("Share") }
            }
        }
        if (meta != null) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { DocFiles.saveToDownloads(ctx, slot, meta) }) { Text("Save to Downloads") }
                TextButton(onClick = {
                    DocFiles.deleteFor(ctx, slot)
                    st.removeDoc(slot.id)
                }) { Text("Delete", color = cs.error) }
            }
        }
    }
}

fun LazyListScope.checklistItems(st: AppState) {
    item {
        val total = checklist.sumOf { it.items.size }
        val done = st.checks.count { it.value }
        AppCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$done of $total ready", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { st.resetChecks() }) { Text("Reset") }
            }
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { if (total == 0) 0f else done.toFloat() / total.toFloat() },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
                color = MaterialTheme.colorScheme.secondary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
    items(checklist) { sec ->
        AppCard {
            Text(sec.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(6.dp))
            sec.items.forEach { item ->
                val checked = st.checks[item.id] ?: false
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { st.toggle(item.id) }.padding(vertical = 6.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Checkbox(checked = checked, onCheckedChange = { st.toggle(item.id) })
                    Column(Modifier.weight(1f).padding(top = 12.dp)) {
                        Text(
                            item.title,
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodyMedium,
                            textDecoration = if (checked) TextDecoration.LineThrough else TextDecoration.None
                        )
                        Text(item.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
