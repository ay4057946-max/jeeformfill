package com.jeeguide.app

// Source: Information Bulletin, JEE (Main) 2027 (NTA). Always verify on https://jeemain.nta.nic.in

const val OFFICIAL_SITE = "https://jeemain.nta.nic.in"

// ---------- Key dates ----------
data class DateItem(val whenText: String, val what: String)

val session1Dates = listOf(
    DateItem("24 Oct – 22 Nov 2026", "Apply online (till 11:50 PM)"),
    DateItem("22 Nov 2026", "Last date for fee payment (11:50 PM)"),
    DateItem("23 – 26 Nov 2026", "Apply with late fee (extra ₹500)"),
    DateItem("27 – 29 Nov 2026", "Correction window"),
    DateItem("30 Dec 2026", "City intimation slip"),
    DateItem("13 Jan 2027", "Admit card download"),
    DateItem("20–24 & 28 Jan 2027", "Session 1 exam dates")
)

val session2Dates = listOf(
    DateItem("5 Jan – 3 Feb 2027", "Apply online (till 11:50 PM)"),
    DateItem("4 – 7 Feb 2027", "Apply with late fee (extra ₹500)"),
    DateItem("8 – 10 Feb 2027", "Correction window"),
    DateItem("12 Mar 2027", "City intimation slip"),
    DateItem("25 Mar 2027", "Admit card download"),
    DateItem("2–7 Apr 2027", "Session 2 exam dates")
)

// ---------- Fees (per session) ----------
val feeSingle = listOf(
    listOf("General", "Male", "₹1,000", "₹5,000"),
    listOf("General", "Female", "₹800", "₹4,000"),
    listOf("Gen-EWS / OBC-NCL", "Male", "₹900", "₹4,500"),
    listOf("Gen-EWS / OBC-NCL", "Female", "₹800", "₹4,000"),
    listOf("SC / ST / PwD / PwBD", "Male", "₹500", "₹2,500"),
    listOf("SC / ST / PwD / PwBD", "Female", "₹500", "₹2,500"),
    listOf("Third Gender", "—", "₹500", "₹2,500")
)

val feeDouble = listOf(
    listOf("General / Gen-EWS / OBC-NCL", "Male", "₹2,000", "₹10,000"),
    listOf("General / Gen-EWS / OBC-NCL", "Female", "₹1,600", "₹8,000"),
    listOf("SC / ST / PwD / PwBD", "Male/Female", "₹1,000", "₹5,000"),
    listOf("Third Gender", "—", "₹1,000", "₹5,000")
)

// ---------- Guide ----------
data class GuideStep(val num: String, val title: String, val tag: String, val points: List<String>)

val guideSteps = listOf(
    GuideStep("1", "Sign in with MeriPehchaan", "Indian candidates", listOf(
        "Open jeemain.nta.nic.in and click the Session 1 registration link.",
        "Choose Indian National (or Foreign National / OCI) and tick the declaration, then proceed.",
        "Sign in via DigiLocker using Mobile, Username or Other ID (Aadhaar / PAN / Driving Licence) with your PIN.",
        "Enter the OTP sent by DigiLocker (valid 10 minutes).",
        "Allow consent to share your details with NTA, then tap 'Complete DigiLocker Verification' once and wait.",
        "When it says verification is complete, tap 'Click here to proceed for Registration'."
    )),
    GuideStep("2", "Registration form", "Get your Application Number", listOf(
        "Type your name exactly as on your Class 10 certificate / marksheet.",
        "Fill father's name, mother's name, date of birth, gender, then confirm each again.",
        "Fill present address, then email and mobile number (OTPs go to these, so they must be yours or a parent's).",
        "Fill permanent address (or tick 'Same as present address').",
        "Create a password: 8–13 characters with an uppercase letter, a lowercase letter, a number and a special character.",
        "Solve the CAPTCHA, review everything, tick Agree and request OTP on your mobile.",
        "Enter the OTP and submit. Note down your Application Number and password immediately."
    )),
    GuideStep("3", "Contact details", "Application form · Section 1", listOf(
        "Log in with your Application Number and password, then tap 'Fill up Application Form'.",
        "Confirm email and mobile. One mobile number and one email can be used for one application only.",
        "Verify the email from the Home page of the application if asked."
    )),
    GuideStep("4", "Personal details", "Application form · Section 2", listOf(
        "Confirm name, date of birth, gender, father's and mother's name.",
        "Select nationality and the State/UT where you passed (or will appear in) Class 12. This is NOT your home state.",
        "Select category (General, Gen-EWS, OBC-NCL, SC, ST). For SC / ST / OBC you must also give: certificate ID/number, issue date and issuing authority.",
        "Also fill: diabetic (yes/no), place of residence, annual family income, mode of preparation, medium of schooling in qualifying exam.",
        "Category and sub-category are also used for JEE Advanced, so choose carefully."
    )),
    GuideStep("5", "Disability details", "Application form · Section 3", listOf(
        "Answer 'Are you a PwD/PwBD candidate?'. If No, just submit.",
        "If Yes, choose whether you hold a UDID card. Enter the UDID number twice, or enter the Disability Certificate number, issuing authority and state.",
        "Pick the type of disability (certificate) and its percentage.",
        "Scribe: for 40% or more with Cerebral Palsy, Locomotor (both arms) or Blindness, you can choose your own scribe or ask NTA for one. Own scribe needs scribe name, date of birth, Aadhaar number and qualification.",
        "Scribe or compensatory time needs a certificate of limitation to write from a Government medical authority (proforma at Annexure II). An own scribe also needs the undertaking at Annexure III.",
        "Compensatory time is 20 minutes per hour of exam."
    )),
    GuideStep("6", "Identity and APAAR ID", "Application form · Sections 4–5", listOf(
        "Identity details come from your DigiLocker verification and are marked completed.",
        "Register APAAR ID: select whether you have one. If Yes, enter the APAAR ID number twice."
    )),
    GuideStep("7", "Apply for and exam cities", "Application form · Section 6", listOf(
        "Choose the paper: Paper 1 (B.E./B.Tech), Paper 2A (B.Arch) or Paper 2B (B.Planning). You can select more than one.",
        "Choose the question paper medium. It cannot be changed after the correction window closes.",
        "Pick up to four exam cities in priority order. Cities are limited to the state of your permanent or present address.",
        "Fill father's and mother's occupation and qualification (mother's is optional)."
    )),
    GuideStep("8", "Qualification details", "Application form · Section 7", listOf(
        "Fill Class 10 (or equivalent) details: year of passing, board, state, roll number, school name and address, PIN.",
        "Fill Class 12 (or equivalent) details: year of passing/appearing (2025, 2026 or 2027), board, roll/registration number, school name and address.",
        "Students appearing in Class 12 in 2027 can enter their roll or registration number."
    )),
    GuideStep("9", "Additional details", "Application form · Section 8", listOf(
        "Answer whether you are a twin who is also applying for JEE Main 2027.",
        "If Yes, give the other twin's name exactly as on the Class 10 certificate and their roll number.",
        "Fill place of birth: state and district."
    )),
    GuideStep("10", "Emergency contact", "Application form · Section 9", listOf(
        "Enter a parent's/guardian's country code, mobile number and email.",
        "Tap Get OTP, then enter both the mobile OTP and the email OTP and verify."
    )),
    GuideStep("11", "Live photograph", "Application form · Section 10", listOf(
        "Switch on your camera or webcam. If your device has no camera, scan the QR code shown with your phone.",
        "Use a white background, good light, and keep 80% of your face visible (ears visible, no mask).",
        "Tap Capture Live Photograph and then Upload Photograph.",
        "If it does not match your identity photo you can recapture, or proceed with the mismatch. Proceeding risks cancellation if impersonation is detected."
    )),
    GuideStep("12", "Upload documents", "Application form · Section 11", listOf(
        "Photograph: JPG/JPEG, 10 KB to 200 KB, colour, recent, white background.",
        "Signature: JPG/JPEG, 10 KB to 100 KB.",
        "Class 10 certificate or marksheet: PDF, 50 KB to 300 KB.",
        "Disability/UDID certificate, certificate for difficulty in writing, and non-Indian passport (foreign nationals/OCI): PDF, 50 KB to 300 KB each.",
        "The uploaded photo is matched with your live photograph. Upload your own documents only."
    )),
    GuideStep("13", "Final submit and review", "Application form · Section 12", listOf(
        "Check every field on the review pages. Once submitted, changes are allowed only in the correction window and only in fields NTA enables.",
        "Tick the declaration and submit. Corrections sent by post, fax, WhatsApp, email or in person are not accepted."
    )),
    GuideStep("14", "Pay the fee", "Step 3", listOf(
        "Pay online by Net Banking, Credit Card, Debit Card or UPI. Bank/gateway charges and GST are extra.",
        "Keep proof of payment (transaction number, bank reference, screenshot).",
        "If the Confirmation Page is not generated, check the payment status with your bank or gateway. If the payment succeeded, contact the NTA helpline. Duplicate payments are refunded after reconciliation.",
        "A successfully paid fee is not refundable."
    )),
    GuideStep("15", "Confirmation page", "Step 4", listOf(
        "The Confirmation Page is generated only after successful payment.",
        "Download, save and print it. Keep your Application Number, it is used for both sessions.",
        "Application is confirmed only when the fee is received."
    ))
)

val golden = listOf(
    "Never submit more than one application. Appearing under two application numbers is treated as unfair means.",
    "Upload only your own photo, signature and certificates.",
    "Keep your Application Number and password safe, and log out when done.",
    "No documents or confirmation page are to be sent to NTA by post or email.",
    "Check your registered email and SMS regularly for NTA updates."
)

// ---------- Checklist ----------
data class CheckItem(val id: String, val title: String, val detail: String)
data class CheckSection(val title: String, val items: List<CheckItem>)

val checklist = listOf(
    CheckSection("Before you start", listOf(
        CheckItem("own_mobile", "Mobile number you can receive OTP on", "Yours or a parent's. One mobile per application."),
        CheckItem("own_email", "Email ID you can open", "One email per application. NTA writes here."),
        CheckItem("digilocker", "DigiLocker / MeriPehchaan account", "Mobile, username, Aadhaar, PAN or Driving Licence with your PIN."),
        CheckItem("emerg", "Parent/guardian mobile and email", "Both get an OTP in the Emergency Contact section."),
        CheckItem("pay", "Payment method ready", "Net Banking, card or UPI with enough balance for fee plus charges."),
        CheckItem("cam", "Device with camera (or phone for QR)", "Needed for the live photograph.")
    )),
    CheckSection("Documents to upload", listOf(
        CheckItem("photo", "Passport-size photograph", "JPG/JPEG, 10–200 KB. Colour, white background, 80% face with ears, no mask."),
        CheckItem("sign", "Signature", "JPG/JPEG, 10–100 KB, clearly legible."),
        CheckItem("c10", "Class 10 certificate / marksheet", "PDF, 50–300 KB. Name on it must match the form."),
        CheckItem("udid", "UDID card or Disability certificate (if PwD/PwBD)", "PDF, 50–300 KB."),
        CheckItem("write", "Certificate of limitation to write (if applicable)", "For scribe / compensatory time. Proforma at Annexure II. PDF, 50–300 KB."),
        CheckItem("passport", "Non-Indian passport (foreign nationals / OCI)", "PDF, 50–300 KB.")
    )),
    CheckSection("Details to keep handy", listOf(
        CheckItem("c12", "Class 12 roll / registration number", "Students appearing in 2027 can enter it in the form."),
        CheckItem("cat", "Category certificate details", "For SC / ST / OBC-NCL: certificate number, issue date, issuing authority."),
        CheckItem("ews", "Gen-EWS certificate", "As per the Government of India EWS criteria."),
        CheckItem("apaar", "APAAR ID (if you have one)", "Entered twice in the APAAR section."),
        CheckItem("parents", "Parents' occupation and qualification", "Mother's details are optional."),
        CheckItem("cities", "Four exam city choices in priority order", "Pick from your state of permanent or present address.")
    )),
    CheckSection("After submitting", listOf(
        CheckItem("conf", "Download and print Confirmation Page", "Only available after successful fee payment."),
        CheckItem("appno", "Note Application Number and password", "Same application number for both sessions."),
        CheckItem("proof", "Save payment proof", "Transaction number and bank reference."),
        CheckItem("corr", "Review in correction window (27–29 Nov 2026)", "Only fields NTA enables can be edited.")
    )),
    CheckSection("Exam day", listOf(
        CheckItem("adm", "Admit card with self-declaration (A4 print)", "Download from 13 Jan 2027 and print at least four copies."),
        CheckItem("pp2", "Two extra passport-size photos", "Same as uploaded. Pasted on the admit card and attendance sheet."),
        CheckItem("pid", "Original valid photo ID", "School ID, PAN, Driving Licence, Voter ID, Passport, Aadhaar, Class 12 admit card, Ration Card or Bank Passbook (with photo)."),
        CheckItem("water", "Transparent water bottle", "Water in a transparent bottle is allowed. Geometry/pencil box, bags and purses are not."),
        CheckItem("draw", "Drawing kit (B.Arch only)", "Bring your own geometry box, pencils, erasers, colour pencils or crayons. No water colours.")
    ))
)

// ---------- Vault / Fast Fill (ordered like the portal) ----------
data class VaultField(
    val key: String,
    val label: String,
    val hint: String = "",
    val kind: Int = 0,        // 0 text, 1 number, 2 email, 3 phone
    val secret: Boolean = false
)
data class VaultGroup(val title: String, val note: String, val fields: List<VaultField>)

private fun addr(p: String) = listOf(
    VaultField(p + "_premises", "Premises no. / name"),
    VaultField(p + "_sub", "Sub-locality (optional)"),
    VaultField(p + "_locality", "Locality"),
    VaultField(p + "_country", "Country", "India"),
    VaultField(p + "_state", "State"),
    VaultField(p + "_district", "District"),
    VaultField(p + "_pin", "PIN code", kind = 1)
)

private fun cls(p: String, status: Boolean) = buildList {
    if (status) add(VaultField(p + "_status", "Status of qualifying exam", "Passed / Appearing"))
    add(VaultField(p + "_year", "Year of passing / appearing", kind = 1))
    add(VaultField(p + "_board", "Board"))
    add(VaultField(p + "_state", "State of qualifying exam"))
    add(VaultField(p + "_district", "District of qualifying exam"))
    add(VaultField(p + "_school_type", "Type of school / college", "Government / Private"))
    add(VaultField(p + "_roll", "Roll / registration number"))
    add(VaultField(p + "_school", "School / college name and address"))
    add(VaultField(p + "_pin", "School / college PIN code", kind = 1))
    add(VaultField(p + "_mode", "Result mode", "Percentage / CGPA"))
    add(VaultField(p + "_total", "Total marks", kind = 1))
    add(VaultField(p + "_marks", "Marks obtained / percentage"))
}

val vaultGroups = listOf(
    VaultGroup("1 · Registration and login", "Keep these safe", listOf(
        VaultField("app_no", "Application Number", kind = 1),
        VaultField("password", "Portal password", secret = true)
    )),
    VaultGroup("2 · Personal details", "Name exactly as on Class 10 certificate", listOf(
        VaultField("name", "Candidate's name"),
        VaultField("dob", "Date of birth", "DD/MM/YYYY"),
        VaultField("gender", "Gender"),
        VaultField("father", "Father / Guardian name"),
        VaultField("mother", "Mother / Guardian name"),
        VaultField("nationality", "Nationality", "Indian"),
        VaultField("state_elig", "State of Class 12 (eligibility)"),
        VaultField("category", "Category", "General / Gen-EWS / OBC-NCL / SC / ST"),
        VaultField("income", "Annual family income"),
        VaultField("diabetic", "Are you diabetic?", "Yes / No"),
        VaultField("residence", "Place of residence"),
        VaultField("prep_mode", "Mode of preparation"),
        VaultField("medium", "Medium of schooling in qualifying exam")
    )),
    VaultGroup("3 · Contact details", "Must be reachable for OTP", listOf(
        VaultField("email", "Email", kind = 2),
        VaultField("mobile", "Mobile number", kind = 3),
        VaultField("alt_mobile", "Alternate mobile (optional)", kind = 3)
    )),
    VaultGroup("4 · Present address", "", addr("pa")),
    VaultGroup("5 · Permanent address", "", addr("pm")),
    VaultGroup("6 · Category certificate", "For SC / ST / OBC-NCL", listOf(
        VaultField("cat_cert_have", "Valid certificate from authorised office?", "Yes / No"),
        VaultField("cat_cert_no", "Category certificate ID / number"),
        VaultField("cat_cert_date", "Certificate issue date", "DD/MM/YYYY"),
        VaultField("cat_cert_auth", "Name of issuing authority")
    )),
    VaultGroup("7 · Disability (PwD/PwBD)", "Only if applicable", listOf(
        VaultField("pwd", "Are you a PwD/PwBD candidate?", "Yes / No"),
        VaultField("has_udid", "Do you have a UDID card / certificate?"),
        VaultField("udid", "UDID card number"),
        VaultField("dis_cert_no", "Disability certificate number"),
        VaultField("dis_auth", "Issuing authority"),
        VaultField("dis_state", "State of issuing authority"),
        VaultField("dis_type", "Type of disability (as per certificate)"),
        VaultField("dis_pct", "Percentage of disability", kind = 1),
        VaultField("scribe_need", "Scribe needed?", "Own scribe / NTA scribe / No")
    )),
    VaultGroup("8 · Scribe details", "Only if you bring your own scribe", listOf(
        VaultField("scribe_name", "Scribe's name"),
        VaultField("scribe_dob", "Scribe's date of birth", "DD/MM/YYYY"),
        VaultField("scribe_aadhaar", "Scribe's Aadhaar number", kind = 1),
        VaultField("scribe_qual", "Scribe's qualification")
    )),
    VaultGroup("9 · Identity and APAAR ID", "Sensitive. Stored only on this phone", listOf(
        VaultField("id_no", "Aadhaar / ID number", kind = 1),
        VaultField("has_apaar", "Do you have an APAAR ID?", "Yes / No"),
        VaultField("apaar", "APAAR ID", kind = 1)
    )),
    VaultGroup("10 · Apply for and exam cities", "", listOf(
        VaultField("paper", "Apply for", "Paper 1 / 2A / 2B"),
        VaultField("paper_medium", "Question paper medium"),
        VaultField("city1_state", "Exam state: 1st choice"),
        VaultField("city1", "Exam city: 1st choice"),
        VaultField("city2_state", "Exam state: 2nd choice"),
        VaultField("city2", "Exam city: 2nd choice"),
        VaultField("city3_state", "Exam state: 3rd choice"),
        VaultField("city3", "Exam city: 3rd choice"),
        VaultField("city4_state", "Exam state: 4th choice"),
        VaultField("city4", "Exam city: 4th choice")
    )),
    VaultGroup("11 · Parents' details", "", listOf(
        VaultField("f_occ", "Father's occupation"),
        VaultField("f_qual", "Father's qualification"),
        VaultField("m_occ", "Mother's occupation (optional)"),
        VaultField("m_qual", "Mother's qualification (optional)")
    )),
    VaultGroup("12 · Class 10 details", "", cls("c10", false)),
    VaultGroup("13 · Class 12 details", "", cls("c12", true)),
    VaultGroup("14 · Additional details", "", listOf(
        VaultField("twin", "Are you a twin also applying?", "Yes / No"),
        VaultField("twin_name", "Twin's name (as on Class 10 certificate)"),
        VaultField("twin_roll", "Twin's Class 10 roll number"),
        VaultField("birth_place", "Place of birth"),
        VaultField("birth_state", "Birth state"),
        VaultField("birth_district", "Birth district")
    )),
    VaultGroup("15 · Emergency contact", "Parent / guardian", listOf(
        VaultField("em_country", "Country code", "+91"),
        VaultField("em_mobile", "Emergency contact mobile", kind = 3),
        VaultField("em_email", "Emergency contact email", kind = 2)
    )),
    VaultGroup("16 · Notes", "Anything else you want to copy", listOf(
        VaultField("note1", "Note 1"),
        VaultField("note2", "Note 2"),
        VaultField("note3", "Note 3")
    ))
)

// ---------- Document locker ----------
data class DocSlot(
    val id: String,
    val title: String,
    val spec: String,
    val image: Boolean,
    val minKB: Int,
    val maxKB: Int,
    val required: Boolean
)

val docSlots = listOf(
    DocSlot("photo", "Passport photograph", "JPG/JPEG · 10–200 KB · colour, white background, 80% face", true, 10, 200, true),
    DocSlot("sign", "Signature", "JPG/JPEG · 10–100 KB · clearly legible", true, 10, 100, true),
    DocSlot("c10", "Class 10 certificate / marksheet", "PDF · 50–300 KB", false, 50, 300, true),
    DocSlot("udid", "UDID / Disability certificate", "PDF · 50–300 KB · only if PwD/PwBD", false, 50, 300, false),
    DocSlot("write", "Certificate of limitation to write", "PDF · 50–300 KB · for scribe / compensatory time", false, 50, 300, false),
    DocSlot("passport", "Non-Indian passport", "PDF · 50–300 KB · foreign nationals / OCI", false, 50, 300, false),
    DocSlot("other1", "Other document 1", "Reference copy · any file", false, 0, 0, false),
    DocSlot("other2", "Other document 2", "Reference copy · any file", false, 0, 0, false)
)
