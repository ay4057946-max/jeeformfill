package com.jeeguide.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

@Composable
fun HomeScreen(st: AppState, go: (Int) -> Unit, onTutorial: () -> Unit, onFastAll: () -> Unit) {
    val days = remember { daysLeft(2026, Calendar.NOVEMBER, 22) }
    val dDone = docSlots.count { it.required && st.docs.containsKey(it.id) }
    val dTotal = docSlots.count { it.required }
    val vDone = st.vault.count { it.value.isNotBlank() }
    val vTotal = vaultGroups.sumOf { it.fields.size }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenHeader("JEE Main 2027", "Your form-filling companion") }
        item { Hero(days) }
        item {
            val shape = RoundedCornerShape(22.dp)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .clickable { onTutorial() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(46.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) { Text("▶", color = MaterialTheme.colorScheme.onPrimary, fontSize = 18.sp) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Watch the animated tutorial", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("45 seconds · how to use this app", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ProgressTile(Modifier.weight(1f), "Documents", dDone, dTotal) { go(3) }
                ProgressTile(Modifier.weight(1f), "Fast Fill fields", vDone, vTotal) { go(2) }
            }
        }
        item { SectionTitle("Quick actions") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ActionTile(Modifier.weight(1f), "Step-by-step guide", "15 steps", MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer) { go(1) }
                    ActionTile(Modifier.weight(1f), "Documents locker", "PDF and photo", MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer) { go(3) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ActionTile(Modifier.weight(1f), "⚡ Fast fill", "Copy field by field", MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer) { onFastAll() }
                    ActionTile(Modifier.weight(1f), "Dates and fees", "Both sessions", MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurface) { go(4) }
                }
            }
        }
        item { SectionTitle("Session 1 timeline") }
        item {
            AppCard {
                session1Dates.forEachIndexed { i, d ->
                    TimelineRow(d, last = i == session1Dates.lastIndex)
                }
            }
        }
        item {
            Text(
                "Unofficial guide based on the NTA Information Bulletin JEE (Main) 2027. Always confirm on jeemain.nta.nic.in.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun Hero(days: Long) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF4F46E5), Color(0xFF7C3AED))))
            .padding(22.dp)
    ) {
        Column {
            Pill("SESSION 1 · JANUARY 2027", Color(0x33FFFFFF), Color.White)
            Spacer(Modifier.height(14.dp))
            if (days >= 0) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("$days", fontSize = 60.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (days == 1L) "day left" else "days left",
                        color = Color(0xFFE0E7FF),
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                }
                Text(
                    "Apply and pay the fee by 22 Nov 2026, 11:50 PM",
                    color = Color(0xFFE0E7FF),
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                Text("Regular window closed", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Late-fee window 23 to 26 Nov 2026. Session 2 forms open from 5 Jan 2027.",
                    color = Color(0xFFE0E7FF),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun ProgressTile(modifier: Modifier, label: String, done: Int, total: Int, onClick: () -> Unit) {
    val frac = if (total == 0) 0f else done.toFloat() / total.toFloat()
    AppCard(modifier, onClick = onClick) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(4.dp))
        Text("$done / $total", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { frac },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

@Composable
private fun ActionTile(modifier: Modifier, title: String, sub: String, bg: Color, fg: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Box(
        modifier
            .clip(shape)
            .background(bg)
            .clickable { onClick() }
            .padding(16.dp)
    ) {
        Column {
            Text(title, color = fg, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(sub, color = fg.copy(alpha = 0.75f), style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(18.dp))
        }
    }
}

@Composable
fun TimelineRow(d: DateItem, last: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.padding(top = 5.dp).size(10.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(d.whenText, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
            Text(d.what, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
