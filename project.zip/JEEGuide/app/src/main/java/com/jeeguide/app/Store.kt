package com.jeeguide.app

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf

/** Local-only storage (SharedPreferences + app-private files). The app has no internet permission. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jee_guide_store", Context.MODE_PRIVATE)
    fun get(k: String): String = sp.getString(k, "") ?: ""
    fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }
    fun getBool(k: String): Boolean = sp.getBoolean(k, false)
    fun putBool(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    fun remove(k: String) { sp.edit().remove(k).apply() }
    fun clear() { sp.edit().clear().apply() }
}

data class DocMeta(val name: String, val size: Long, val mime: String, val ext: String) {
    fun encode() = listOf(name, size.toString(), mime, ext).joinToString("\t")
    companion object {
        fun decode(s: String): DocMeta? {
            val p = s.split("\t")
            if (p.size < 4) return null
            return DocMeta(p[0], p[1].toLongOrNull() ?: 0L, p[2], p[3])
        }
    }
}

class AppState(private val store: Store) {
    val vault = mutableStateMapOf<String, String>()
    val checks = mutableStateMapOf<String, Boolean>()
    val docs = mutableStateMapOf<String, DocMeta>()

    init {
        vaultGroups.forEach { g -> g.fields.forEach { f -> vault[f.key] = store.get("v_" + f.key) } }
        checklist.forEach { s -> s.items.forEach { i -> checks[i.id] = store.getBool("c_" + i.id) } }
        docSlots.forEach { d ->
            val m = DocMeta.decode(store.get("d_" + d.id))
            if (m != null) docs[d.id] = m
        }
    }

    fun setVault(key: String, value: String) {
        vault[key] = value
        store.put("v_$key", value)
    }

    fun toggle(id: String) {
        val now = !(checks[id] ?: false)
        checks[id] = now
        store.putBool("c_$id", now)
    }

    fun resetChecks() {
        checks.keys.toList().forEach { checks[it] = false; store.putBool("c_$it", false) }
    }

    fun setDoc(id: String, m: DocMeta) {
        docs[id] = m
        store.put("d_$id", m.encode())
    }

    fun removeDoc(id: String) {
        docs.remove(id)
        store.remove("d_$id")
    }

    fun clearAll(ctx: Context) {
        store.clear()
        DocFiles.deleteAll(ctx)
        vault.keys.toList().forEach { vault[it] = "" }
        checks.keys.toList().forEach { checks[it] = false }
        docs.clear()
    }
}
