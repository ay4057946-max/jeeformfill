package com.jeeguide.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private const val SCENE_MS = 7000L
private val Soft = Color(0xFFC7D2FE)

/** Smooth 0..1 progress of t between a and b. */
private fun seg(t: Float, a: Float, b: Float): Float {
    val x = ((t - a) / (b - a)).coerceIn(0f, 1f)
    return x * x * (3f - 2f * x)
}

private fun Modifier.pop(p: Float): Modifier = this.graphicsLayer {
    val s = 0.6f + 0.4f * p
    scaleX = s
    scaleY = s
    alpha = p
}

private fun Modifier.rise(p: Float): Modifier = this.graphicsLayer {
    translationY = (1f - p) * 60f
    alpha = p
}

@Composable
private fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(20.dp)).background(Color(0x26FFFFFF)).padding(16.dp),
        content = content
    )
}

private class SceneInfo(val title: String, val caption: String, val content: @Composable (Float) -> Unit)

private val scenes = listOf(
    SceneInfo("Welcome", "Everything for the JEE Main 2027 form in one offline app.") { t -> Scene1(t) },
    SceneInfo("Save your details once", "Type them one time. They stay on your phone and nothing is uploaded.") { t -> Scene2(t) },
    SceneInfo("Copy and paste in one tap", "Tap Copy, switch to the NTA portal and paste. Fast Fill walks you through every field.") { t -> Scene3(t) },
    SceneInfo("Keep documents ready", "Add your photo, signature and PDFs. Photos are shrunk to the NTA size limit for you.") { t -> Scene4(t) },
    SceneInfo("Follow the guide", "Step-by-step help for every section of the application form.") { t -> Scene5(t) },
    SceneInfo("Pay and save proof", "Pay the fee, download the Confirmation Page and note your Application Number.") { t -> Scene6(t) }
)

@Composable
fun TutorialScreen(onClose: () -> Unit) {
    BackHandler { onClose() }
    val n = scenes.size
    val total = n * SCENE_MS
    var elapsed by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(true) }

    LaunchedEffect(playing) {
        if (playing) {
            var last = withFrameMillis { it }
            while (true) {
                val now = withFrameMillis { it }
                elapsed = (elapsed + (now - last)).coerceAtMost(total)
                last = now
                if (elapsed >= total) {
                    playing = false
                    break
                }
            }
        }
    }

    val idx = (elapsed / SCENE_MS).toInt().coerceAtMost(n - 1)
    val t = ((elapsed - idx * SCENE_MS).toFloat() / SCENE_MS.toFloat()).coerceIn(0f, 1f)
    val sc = scenes[idx]

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF14123A), Color(0xFF2E2A7A))))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            for (i in 0 until n) {
                val f = ((elapsed - i * SCENE_MS).toFloat() / SCENE_MS.toFloat()).coerceIn(0f, 1f)
                Box(
                    Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(50)).background(Color(0x33FFFFFF))
                ) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(f).background(Color.White))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Animated tutorial · ${idx + 1}/$n",
                color = Soft,
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onClose) { Text("✕ Close", color = Color.White) }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)) { sc.content(t) }
        Column(Modifier.graphicsLayer { alpha = seg(t, 0f, 0.1f) }) {
            Text(sc.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(sc.caption, color = Soft, style = MaterialTheme.typography.bodyMedium)
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                val target = if (t > 0.15f) idx else (idx - 1).coerceAtLeast(0)
                elapsed = target * SCENE_MS
                playing = true
            }) { Text("◀ Prev", color = Color.White) }
            Button(onClick = {
                if (elapsed >= total) {
                    elapsed = 0L
                    playing = true
                } else {
                    playing = !playing
                }
            }) { Text(if (elapsed >= total) "↻ Replay" else if (playing) "❚❚ Pause" else "▶ Play") }
            TextButton(onClick = {
                if (idx >= n - 1) {
                    elapsed = total
                    playing = false
                } else {
                    elapsed = (idx + 1) * SCENE_MS
                    playing = true
                }
            }) { Text("Next ▶", color = Color.White) }
        }
    }
}

// ---------------- Scenes ----------------

@Composable
private fun Scene1(t: Float) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(contentAlignment = Alignment.Center) {
            val ring = (t * 3f) % 1f
            val appear = seg(t, 0f, 0.2f)
            Box(
                Modifier
                    .size(150.dp)
                    .graphicsLayer {
                        val s = 0.8f + ring * 0.6f
                        scaleX = s
                        scaleY = s
                        alpha = (1f - ring) * 0.35f * appear
                    }
                    .clip(CircleShape)
                    .background(Color(0xFFA5B4FC))
            )
            Box(
                Modifier
                    .size(110.dp)
                    .pop(seg(t, 0f, 0.25f))
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Color(0xFF6366F1), Color(0xFF8B5CF6)))),
                contentAlignment = Alignment.Center
            ) { Text("✓", fontSize = 56.sp, color = Color.White, fontWeight = FontWeight.Black) }
        }
        Spacer(Modifier.height(24.dp))
        Text("JEE Main 2027", fontSize = 30.sp, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.rise(seg(t, 0.25f, 0.45f)))
        Spacer(Modifier.height(8.dp))
        Text("Form filling, made simple", color = Soft, modifier = Modifier.rise(seg(t, 0.35f, 0.55f)))
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Guide", "Fast Fill", "Documents").forEachIndexed { i, s ->
                Box(Modifier.pop(seg(t, 0.55f + i * 0.1f, 0.7f + i * 0.1f))) {
                    Pill(s, Color(0x33FFFFFF), Color.White)
                }
            }
        }
    }
}

@Composable
private fun Scene2(t: Float) {
    val rows = listOf(
        "Candidate's name" to "Aarav Kumar",
        "Date of birth" to "14/08/2008",
        "Mobile" to "98765 43210",
        "Email" to "aarav@email.com"
    )
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Glass(Modifier.fillMaxWidth()) {
            Text("My details", color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            rows.forEachIndexed { i, row ->
                val a = 0.08f + i * 0.17f
                val p = seg(t, a, a + 0.1f)
                val ty = seg(t, a + 0.05f, a + 0.17f)
                val v = row.second
                val caret = if (ty > 0f && ty < 1f) "▍" else ""
                Column(Modifier.rise(p).padding(vertical = 6.dp)) {
                    Text(row.first, color = Soft, style = MaterialTheme.typography.labelSmall)
                    Text(v.take((v.length * ty).toInt()) + caret, color = Color.White, style = MaterialTheme.typography.titleMedium)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Box(Modifier.pop(seg(t, 0.8f, 0.92f))) {
            Pill("🔒 Saved only on this phone", Color(0x3322C55E), Color(0xFF86EFAC))
        }
    }
}

@Composable
private fun Scene3(t: Float) {
    val name = "Aarav Kumar"
    val appIn = seg(t, 0f, 0.12f)
    val portalIn = seg(t, 0.08f, 0.2f)
    val press = seg(t, 0.28f, 0.34f) - seg(t, 0.34f, 0.42f)
    val fly = seg(t, 0.4f, 0.62f)
    val typed = seg(t, 0.62f, 0.85f)
    val done = seg(t, 0.86f, 0.95f)
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
        Glass(Modifier.fillMaxWidth().rise(appIn)) {
            Text("JEE Guide · Fast Fill", color = Soft, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(Color(0x22FFFFFF)).padding(12.dp)
                ) { Text(name, color = Color.White, fontWeight = FontWeight.SemiBold) }
                Spacer(Modifier.width(10.dp))
                Box(
                    Modifier
                        .graphicsLayer {
                            val s = 1f - 0.12f * press
                            scaleX = s
                            scaleY = s
                        }
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (press > 0.3f) Color(0xFF34D399) else Color(0xFF6366F1))
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) { Text(if (press > 0.3f) "Copied" else "Copy", color = Color.White, fontWeight = FontWeight.Bold) }
            }
        }
        Box(Modifier.fillMaxWidth().height(96.dp), contentAlignment = Alignment.TopCenter) {
            if (fly > 0f && fly < 1f) {
                Box(Modifier.offset(y = (fly * 56f).dp).graphicsLayer { alpha = 1f - 0.4f * fly }) {
                    Pill(name, Color(0xFF6366F1), Color.White)
                }
            }
            Text("⬇", color = Soft, fontSize = 26.sp, modifier = Modifier.align(Alignment.Center).graphicsLayer { alpha = 0.5f })
        }
        Glass(Modifier.fillMaxWidth().rise(portalIn)) {
            Text("NTA portal · Candidate's name", color = Soft, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                val shown = name.take((name.length * typed).toInt()) + if (typed > 0f && typed < 1f) "▍" else ""
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(Color(0x22FFFFFF)).padding(12.dp)
                ) { Text(if (shown.isEmpty()) " " else shown, color = Color.White, fontWeight = FontWeight.SemiBold) }
                Spacer(Modifier.width(10.dp))
                Box(Modifier.pop(done)) { Text("✓", color = Color(0xFF4ADE80), fontSize = 24.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun Scene4(t: Float) {
    val items = listOf(
        listOf("Passport photo", "1.8 MB", "148 KB", "🖼️"),
        listOf("Signature", "620 KB", "64 KB", "✍️"),
        listOf("Class 10 marksheet (PDF)", "212 KB", "212 KB", "📄")
    )
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        items.forEachIndexed { i, d ->
            val s = 0.06f + i * 0.2f
            val pin = seg(t, s, s + 0.1f)
            val prog = seg(t, s + 0.08f, s + 0.24f)
            val sub = when {
                prog < 0.6f -> "Original: " + d[1]
                i == 2 -> d[2] + " · within 50–300 KB"
                else -> d[2] + " · resized to fit"
            }
            Glass(Modifier.fillMaxWidth().rise(pin)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x33FFFFFF)),
                        contentAlignment = Alignment.Center
                    ) { Text(d[3]) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(d[0], color = Color.White, fontWeight = FontWeight.Bold)
                        Text(sub, color = Soft, style = MaterialTheme.typography.bodySmall)
                    }
                    Box(Modifier.pop(seg(prog, 0.85f, 1f))) {
                        Text("✓", color = Color(0xFF4ADE80), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)).background(Color(0x33FFFFFF))) {
                    Box(Modifier.fillMaxWidth(prog).fillMaxHeight().background(Color(0xFF818CF8)))
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        Box(Modifier.pop(seg(t, 0.8f, 0.92f))) {
            Pill("Checks NTA size limits for you", Color(0x3322C55E), Color(0xFF86EFAC))
        }
    }
}

@Composable
private fun Scene5(t: Float) {
    val steps = listOf(
        "Contact details", "Personal details", "Disability details", "Exam cities",
        "Qualification", "Emergency contact", "Live photograph", "Upload documents"
    )
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
        Glass(Modifier.fillMaxWidth()) {
            val doneCount = steps.indices.count { seg(t, 0.1f + it * 0.1f, 0.18f + it * 0.1f) >= 1f }
            Text("Application form · $doneCount of ${steps.size}", color = Soft, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(8.dp))
            steps.forEachIndexed { i, label ->
                val c = seg(t, 0.1f + i * 0.1f, 0.18f + i * 0.1f)
                Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(if (c >= 1f) Color(0xFF22C55E) else Color(0x33FFFFFF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.pop(c)) { Text("✓", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(label, color = if (c >= 1f) Color.White else Soft, fontWeight = if (c >= 1f) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
private fun Scene6(t: Float) {
    val burst = seg(t, 0.55f, 1f)
    val colors = listOf(Color(0xFFF472B6), Color(0xFF60A5FA), Color(0xFFFBBF24), Color(0xFF34D399))
    val appNo = "2701 0000 0000"
    val typed = seg(t, 0.5f, 0.75f)
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        for (i in 0 until 14) {
            val ang = i * 2.0 * PI / 14.0
            val r = 50f + 150f * burst
            Box(
                Modifier
                    .offset(x = (cos(ang) * r).toFloat().dp, y = (sin(ang) * r * 0.8).toFloat().dp)
                    .size(8.dp)
                    .graphicsLayer { alpha = (1f - burst) * seg(t, 0.55f, 0.6f) }
                    .clip(CircleShape)
                    .background(colors[i % 4])
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(90.dp).pop(seg(t, 0f, 0.2f)).clip(CircleShape).background(Color(0xFFF59E0B)),
                contentAlignment = Alignment.Center
            ) { Text("₹", fontSize = 44.sp, color = Color.White, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(10.dp))
            Text("Fee paid", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.rise(seg(t, 0.15f, 0.3f)))
            Spacer(Modifier.height(20.dp))
            Glass(Modifier.fillMaxWidth().rise(seg(t, 0.3f, 0.45f))) {
                Text("Confirmation Page", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Application No: " + appNo.take((appNo.length * typed).toInt()),
                    color = Soft,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            Spacer(Modifier.height(14.dp))
            Text("Download · Print · Keep it safe", color = Soft, modifier = Modifier.rise(seg(t, 0.75f, 0.9f)))
        }
    }
}
